#include <stdio.h>
#include <stdlib.h>
#include <math.h>
// AI5005 Advanced Data Structures and Algorithms
// Kranthi Kumar P
//AI20RESCH14002
//02-10-2020
//Assignment-1, Solution-1


// find Kth root function
int findKthroot(long n,long k);


void main()
{
    // Enter # samples
    int s = 4;
    // Enter Array Values
    long data['s'][2] = {{64,3},{15,2},{10,5},{23,4}};

    // running for loop for each sample data
    for (int i=0;i<s;i++)
    {
        int val = findKthroot(data[i][0],data[i][1]);
        if (val != 0) // if value is out of bounds then the function return '0'
        {
            printf("Value is %d\n",val);
        }

    }
}
// Applying divide and conquer paradigm and binary search - the time complexity of the algorithm is O(log n)
int findKthroot(long n,long k)
{
    long first = 0;
    long last = n;
    long mid = (first+last)/2;
    // checking inputs for constraints
    if ((n < 1) || (n > pow(10,16)))
    {
        printf("Input is out of bounds\n");
    } else if ((k < 1) || (k > n))
    {
        printf("Input is out of bounds\n");
    } else
    {
        // checking mid value for k th root
        while (!((pow(mid,k) <= n)&&(pow(mid+1,k) > n)))
        {
            if (pow(mid,k) <= n)
            {
                first = mid+1;
            }
            if (pow(mid,k) > n)
            {
                last = mid-1;
            }
            mid = (first+last)/2;
        }
        return mid;
    }
}
