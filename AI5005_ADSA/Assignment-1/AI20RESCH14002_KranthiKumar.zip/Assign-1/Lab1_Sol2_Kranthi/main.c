#include <stdio.h>
#include <stdlib.h>
#include <math.h>
// AI5005 Advanced Data Structures and Algorithms
// Kranthi Kumar P
//AI20RESCH14002
//03-10-2020
//Assignment-1, Solution-2

// Function definitions
int mergeSort(int arr_in[], int array_size);
int merge_Sort(int arr_in[], int temp[], int L, int R);
int merge(int arr_in[], int temp[], int L, int mid, int R);


// The time complexity of the algorithm is O(n log n)
int main()
{
    //Input
    int elements = 10; //Enter 3 elements in the array
    int arr_in[] = {3, 8, 0, -4, 1, 9, -5, 6, 2, 4};// Enter array Values
    //checking for constraints
    if (elements > pow(10,5))
    {
        printf("Input is out of bounds.\n");
    }
    else
    {
        int inv = mergeSort(arr_in, elements);
        printf("Number of Inversions are %d \n", inv);
    }
    return;
}

//Function for sorting the input array and return #inversions
int mergeSort(int arr_in[], int array_size)
{
    int* temp = (int*)malloc(sizeof(int) * array_size);
    return merge_Sort(arr_in, temp, 0, array_size - 1);
}

//Recursive function that sorts the input sub array and returns #inversions
int merge_Sort(int arr_in[], int temp[], int L, int R)
{
    int mid, countof_Inv = 0;
    if (R > L) {
        // Divide into parts
        mid = (R + L) / 2;

        // counting inversions in both sub arrays
        countof_Inv += merge_Sort(arr_in, temp, L, mid);
        countof_Inv += merge_Sort(arr_in, temp, mid + 1, R);

        // merge together
        countof_Inv += merge(arr_in, temp, L, mid + 1, R);
    }
    return countof_Inv;
}

// function for merging two arrays
int merge(int arr_in[], int temp[], int L, int mid, int R)
{
    int i, j, k;
    int countof_Inv = 0;

    i = L;
    j = mid;
    k = L;
    while ((i <= mid - 1) && (j <= R)) {
        if (arr_in[i] <= arr_in[j]) {
            temp[k++] = arr_in[i++];
        }
        else {
            temp[k++] = arr_in[j++];
            countof_Inv = countof_Inv + (mid - i);
        }
    }

   // copying remaining elements of left sub array
    while (i <= mid - 1)
    {
        temp[k++] = arr_in[i++];
    }


    // copying remaining elements of right sub array
    while (j <= R)
    {
        temp[k++] = arr_in[j++];
    }


    //update original array
    for (i = L; i <= R; i++)
    {
        arr_in[i] = temp[i];
    }


    return countof_Inv;
}
